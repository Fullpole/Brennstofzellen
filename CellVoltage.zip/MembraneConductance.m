function [CM, CMUnc] = MembraneConductance (lambda,C)


    for i=1:C.NumParam.NumSegments  
    
   
        if lambda(i) < 1.253    % wenn Lambda < 1.253, dann ist die speziefische Leitfähigkeit = 0 [S/m]
        
            CMUnc(i) = 0;
            
        else 
          
            CMUnc(i)= (0.005738*lambda(i)-0.007192)*100;
        
        end
    
            if CMUnc(i) < 0.2    % wenn speziefische Leitfähigkeit unter 0.2 [S/m] ist, wird sie auf 0.2 [S/m] beschränkt

               CM(i) = 0.2;

            else 

                CM(i) = CMUnc(i);
            
            end

    end

end