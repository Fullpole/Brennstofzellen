figure(3); 
set(gcf, 'PaperPositionMode', 'auto');    % sorgt dafür, dass die Grafiken richtig ausgedruckt werden
set(gcf, 'Position', [1050 500 500 400]); % legt die Position und Größe auf dem Monitor fest


ylim([0 1]); % legt das Sichtfenster fest
xlim([0 1]);


plot(PositionElements, rH(1,:), 'o-', 'LineWidth', 2, 'MarkerSize', 6, 'Color', [0.7 0.6 1]); % rH(1,:) liefert alle Einträge der ersten Zeile
grid on;
grid minor;
title('Humidities');
xlabel('position along cathode channel');
ylabel('relative humidity');
