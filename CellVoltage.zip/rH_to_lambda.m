function [lambda] = rH_to_lambda (rH,C)

%rH = [0.0580,    0.1720,   0.2834,    0.3924,    0.4989,    0.6031,    0.7050,    0.8048,   0.9024];


    for i=1:C.NumParam.NumSegments

    lambda(i) = 0.3+6*rH(i)*(1-tanh(rH(i)-0.5))+3.9*sqrt(rH(i))*(1+tanh((rH(i)-0.89)/0.23)); 

    end

end