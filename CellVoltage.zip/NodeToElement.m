function [MC_Elements] = NodeToElement (MC_Nodes)
  
  MC_Elements=zeros((length(MC_Nodes(:, 1))-1), length(MC_Nodes(1, :)));
  
  for i=1:(length(MC_Nodes(:, 1))-1)
    MC_Elements(i, :)= (MC_Nodes(i, :) + MC_Nodes(i+1, :))/2;
  end

end
  
