function [rH] = media_to_rH (MC_Elements, C, psat)



for i=1:C.NumParam.NumSegments

rH(i) = ((MC_Elements(i,2)/(MC_Elements(i,1)+MC_Elements(i,2)+MC_Elements(i,3)))*C.OP.PoutCathode)/psat;  % rH = ((ni/nges)*pges)/psat



end

end