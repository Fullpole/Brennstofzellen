%%% function to calculate the inlet media flow of the cathode

function MC_IN = MediaCalculation_Cath_IN(C)
  
  LoadedMolarFlow=C.OP.StackCurrent*C.FCParam.NumberOfCells/C.Const.F;        % Molar charged particles [mol / s]
  
  MolarOxygenFlow=LoadedMolarFlow/4*C.OP.StoicCathode;                        % Oxygen flow including the stoichiometry factor [mol / s]
  
  MolarNitrogenFlow=MolarOxygenFlow/C.Const.MolAntO2*(1-C.Const.MolAntO2);    % Nitrogen flow resulting from the molar fraction of oxygen to nitrogen [mol / s]
  
  MC_IN(1)=MolarOxygenFlow;   % [mol / s]
  MC_IN(2)=0;                 % [mol / s]
  MC_IN(3)=MolarNitrogenFlow; % [mol / s]

end