function [psat] = SaturationPressure (C)


A=-5800.2206;
B=1.3914993;
G=-0.048640239;
D=4.17648*10^-5;
E=-1.44521*10^-8;
F=6.545973;

psat= exp(A/(C.OP.StackTemperature)+B+G*(C.OP.StackTemperature)+D*(C.OP.StackTemperature)^2+E*(C.OP.StackTemperature)^3+F*log(C.OP.StackTemperature));



end

