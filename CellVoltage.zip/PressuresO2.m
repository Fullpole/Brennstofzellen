function [pO2ref,pO2] = PressuresO2 (MC_Nodes,MC_Elements,C)

pO2ref = (MC_Nodes((1:end-1), 1)./(MC_Nodes((1:end-1), 1)+MC_Nodes((1:end-1), 2)+MC_Nodes((1:end-1), 3)))*C.OP.PoutCathode;

pO2 = (MC_Elements(:, 1)./(MC_Elements(:, 1)+MC_Elements(:, 2)+MC_Elements(:, 3)))*C.OP.PoutCathode;


end