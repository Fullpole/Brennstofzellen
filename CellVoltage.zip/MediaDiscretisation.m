function [MC_Nodes]= MediaDiscretisation (MC_Cell_In, C, I)
  
  MC_Nodes=zeros((C.NumParam.NumSegments+1), 3);
  
  MC_Nodes(1, :)=MC_Cell_In;
  
  %SegmentCurrent=C.OP.StackCurrent/C.NumParam.NumSegments;                         % A
  for i=1:C.NumParam.NumSegments
    MC_Nodes(i+1, 1)=MC_Nodes(i, 1)-I(i)/C.Const.F/4; % [mol / s]
    MC_Nodes(i+1, 2)=MC_Nodes(i, 2)+I(i)/C.Const.F/2; % [mol / s]
    MC_Nodes(i+1, 3)=MC_Nodes(i, 3);               % [mol / s]
  end
  
end
