function C = DefineBoundaryConditions ()

%%% Constants
C.Const.F=96485.33212;      % Faraday Constant [As/mol]
C.Const.MolAntO2=0.20942;   % molar fraction O2 in Air [-]
C.Const.MH2O=18.01528;      % molar mass of gaseous water [g/mol]
C.Const.VM=22.414;          % volume of one mol at norm conditions [m3/mol]
C.Const.Area=300;           % [cm^2]
%%% geometric fuel cell parameters
C.FCParam.ActiveArea=0.03;          % Active Area [m*m]
C.FCParam.NumberOfCells=400;        % Number of Cells [-]
C.FCParam.MembraneThickness=15*10^-6; % Membrandicke
%%% numerical parameters
C.NumParam.NumSegments = 9;   % Number of Segments along the cathode channel

%%% operating point
C.OP.StackCurrent=300;            % stack current [A]
C.OP.StoicCathode=2;              % stoichiometry on cathode side [-]
C.OP.RHCathode=0;                 % relative humidity on cathode side [%]
C.OP.StackTemperature=333.15;     % StackTemperature [K]
C.OP.PoutCathode=10^5;            % Druck am Ausgang der Kathode [Pa]

C.Calib.A=0.03;                   %Tafelsteigung                      
C.Calib.iCROSS=10^-8;             %Verluststromdichte
C.Calib.i0=0.8;                     
C.Calib.m=7*10^-3;
C.Calib.n=0.9; 
C.Calib.Ohm=1;

end
