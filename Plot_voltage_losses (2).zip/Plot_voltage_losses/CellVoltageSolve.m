function Error = CellVoltageSolve (C, I, CM, pO2, pO2ref)

Error=CellVoltage (C, I, CM, pO2, pO2ref);


% 
% U_mean = mean(U_cell);
% 
% Error = Spannung-U_mean;

end