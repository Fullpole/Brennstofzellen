figure(5);
set(gcf, 'PaperPositionMode', 'auto');    % sorgt dafür, dass die Grafiken richtig ausgedruckt werden
set(gcf, 'Position', [50 50 600 400]); % legt die Position und Größe auf dem Monitor fest


ylim([0 1.3]); % legt das Sichtfenster fest
xlim([0 1]);

hold on;
plot(PositionElements, U_act(:,1), 'o-', 'LineWidth', 2, 'MarkerSize', 3, 'Color', [1 0 0]); % CM(1,:) liefert alle Einträge der ersten Zeile
plot(PositionElements, U_cell(:,1), 'o-', 'LineWidth', 2, 'MarkerSize', 3, 'Color', [0.25 0.75 0.25]);
plot(PositionElements, U_conc(:,1), 'o-', 'LineWidth', 2, 'MarkerSize', 3, 'Color', [0 0 1]);
plot(PositionElements, U_ideal(:,1), 'o-', 'LineWidth', 2, 'MarkerSize', 3, 'Color', [1 0.5 0]);
plot(PositionElements, U_ohm(:,1), 'o-', 'LineWidth', 2, 'MarkerSize', 3, 'Color', [1 0 0.8]);

LEGENDE=[];
LEGENDE{1}=('activation losses');
LEGENDE{2}=('cell voltage');
LEGENDE{3}=('concentration losses');
LEGENDE{4}=('ideal cell voltage');
LEGENDE{5}=('ohmic losses');
cleg=legend(LEGENDE, 'location', 'northeastoutside');

grid on;
grid minor;
title('CellVoltages');
xlabel('position along cathode channel');
ylabel('U [V]');
