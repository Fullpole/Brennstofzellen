figure(4);
set(gcf, 'PaperPositionMode', 'auto');    % sorgt dafür, dass die Grafiken richtig ausgedruckt werden
set(gcf, 'Position', [1550 550 500 400]); % legt die Position und Größe auf dem Monitor fest


ylim([0 4]); % legt das Sichtfenster fest
xlim([0 1]);


plot(PositionElements, CM(1,:), 'o-', 'LineWidth', 2, 'MarkerSize', 6, 'Color', [1 0.5 0]); % CM(1,:) liefert alle Einträge der ersten Zeile
grid on;
grid minor;
title('Conductivities');
xlabel('position along cathode channel');
ylabel('specific conductivity [S/m]');
