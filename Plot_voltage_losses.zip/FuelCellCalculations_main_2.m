%%% chapter 1

%%% boundary conditions
clear;
close all;
close all hidden;
C = DefineBoundaryConditions;



%%% Media Calculations stack and cell level
[MC_Stack_In] = MediaCalculation_Cath_IN(C);
MC_Cell_In = MC_Stack_In/C.FCParam.NumberOfCells;



%%% calculation electrochemical reaction along the channel
I=ones(C.NumParam.NumSegments, 1).*C.OP.StackCurrent/C.NumParam.NumSegments; %calculation of the current "I" of each segment
[MC_Nodes] = MediaDiscretisation (MC_Cell_In, C, I);
[MC_Elements] = NodeToElement (MC_Nodes);




%%% chapter 2

%%% Calculation of Membrane resistance
[psat] = SaturationPressure (C);               % calculation of the saturation pressure
[rH] = media_to_rH (MC_Elements, C, psat);     % calculation of the relative humidity
[lambda] = rH_to_lambda (rH,C);                % calculation of the coefficient lambda
[CM, CMUnc] = MembraneConductance (lambda,C);  % calculation of the specific conductivity

%%% chapter 3

[pO2ref, pO2] = PressuresO2 (MC_Nodes,MC_Elements,C);
[U_cell, U_ideal, U_act, U_ohm, U_conc] = CellVoltage (C, I, CM, pO2, pO2ref);


%%% plot of the results
Positions;

Plot_MediaFlowCathode;
Plot_Humidities;
Plot_Conductivities;
Plot_voltage_losses;

