function [U_cell, U_ideal, U_act, U_ohm, U_conc] = CellVoltage (C, I, CM, pO2,pO2ref)


    for i=1:C.NumParam.NumSegments
        
        U_cell(i) = 
        
        U_ideal(i) = -Delta_G / (z * F);
        
        U_act(i) = alpha * log(i + i_cross/ i0);
        
        U_ohm(i) =
        
        U_conc(i) =

    end

end


U_ideal = -Delta_G / (z * F);
U_act = alpha * log(i / i0);
U_act = a * log((i + i_cross) / i0);
i0 = C_i0 * p_O2_ref * 2e-7 - 0.0015;
U_ohm = (i + i_cross) * ((d_M / sigma_lambda) * C_ohm + R_el);
U_ohm = (i + i_cross) * ((d_M / sigma_lambda) * C_ohm);
U_conc = C_m * exp(n * i);
n = C_n * (0.0001340428 * log(p_O2_ref / p_O2) + 0.0000629589) * (p_O2_ref * (-10^-5) + 1.6574)^(p_O2)
j = zFk0_redc_red exp(-Delta_R_G_star_a_0 / (RT)) exp(-((1 - alpha)FDelta_phi) / (RT))  - zFk0_oxc_ox   * exp(-Delta_R_G_star_k_0 / (RT)) exp(-(alphaFDelta_phi) / (R*T));